'use client'

import { motion } from 'framer-motion'

const stats = [
  { value: '70%', label: 'Fewer Support Tickets' },
  { value: '24/7', label: 'AI Customer Support' },
  { value: '3x', label: 'Faster Response Times' },
  { value: '95%', label: 'Customer Satisfaction' },
]

const features = [
  'AI Chat Assistant',
  'Ticket Automation',
  'Email Response Automation',
  'Knowledge Base AI',
  'Omnichannel Support',
  'Analytics Dashboard',
]

export default function Home() {
  return (
    <main className="min-h-screen bg-black text-white overflow-hidden">
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_top,rgba(100,100,255,0.2),transparent_40%)]" />

      <section className="relative max-w-7xl mx-auto px-6 py-24">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="text-center"
        >
          <div className="inline-flex px-4 py-2 rounded-full border border-white/10 bg-white/5 backdrop-blur-sm mb-6">
            AI Customer Support Automation
          </div>

          <h1 className="text-5xl md:text-7xl font-bold leading-tight max-w-5xl mx-auto">
            Reduce Customer Support Workload by
            <span className="block text-transparent bg-clip-text bg-gradient-to-r from-white to-gray-400">
              70% With AI
            </span>
          </h1>

          <p className="max-w-3xl mx-auto text-gray-400 text-lg mt-8">
            Deploy intelligent AI agents that answer questions instantly,
            automate tickets, and respond to customers 24/7 without increasing
            headcount.
          </p>

          <div className="flex justify-center gap-4 mt-10 flex-wrap">
            <button className="px-8 py-4 rounded-xl bg-white text-black font-semibold">
              Book Demo
            </button>

            <button className="px-8 py-4 rounded-xl border border-white/20 bg-white/5">
              See Platform
            </button>
          </div>
        </motion.div>

        <div className="mt-20 max-w-5xl mx-auto">
          <div className="rounded-3xl border border-white/10 bg-white/5 backdrop-blur-xl p-8">
            <div className="grid md:grid-cols-2 gap-8">
              <div>
                <h3 className="font-semibold mb-4">
                  Live AI Conversation Demo
                </h3>

                <div className="space-y-3">
                  <div className="bg-white/10 rounded-xl p-3">
                    Customer: Where is my order?
                  </div>

                  <div className="bg-indigo-500/20 rounded-xl p-3">
                    AI: I&apos;ve located your order. It will arrive tomorrow by
                    3PM.
                  </div>

                  <div className="bg-white/10 rounded-xl p-3">
                    Customer: Can I change the address?
                  </div>

                  <div className="bg-indigo-500/20 rounded-xl p-3">
                    AI: Yes. I&apos;ve sent you a secure address update form.
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                {stats.map((stat) => (
                  <div
                    key={stat.label}
                    className="rounded-2xl bg-white/5 border border-white/10 p-5"
                  >
                    <div className="text-3xl font-bold">{stat.value}</div>
                    <div className="text-gray-400 text-sm mt-2">
                      {stat.label}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className="max-w-7xl mx-auto px-6 py-24">
        <h2 className="text-4xl font-bold text-center mb-16">
          Support Teams Are Drowning In Repetitive Requests
        </h2>

        <div className="grid md:grid-cols-5 gap-6">
          {[
            'Repetitive Questions',
            'Slow Response Times',
            'Growing Ticket Backlog',
            'Rising Support Costs',
            'Burned-Out Teams',
          ].map((item) => (
            <div
              key={item}
              className="p-6 rounded-2xl border border-white/10 bg-white/5"
            >
              {item}
            </div>
          ))}
        </div>
      </section>

      <section className="max-w-7xl mx-auto px-6 py-24">
        <h2 className="text-4xl font-bold text-center mb-16">
          One AI Platform. Complete Customer Support Automation.
        </h2>

        <div className="grid md:grid-cols-3 gap-6">
          {features.map((feature) => (
            <div
              key={feature}
              className="rounded-2xl border border-white/10 bg-white/5 p-8"
            >
              <h3 className="text-xl font-semibold">{feature}</h3>

              <p className="text-gray-400 mt-3">
                Enterprise-grade AI automation designed to scale customer
                support operations while reducing manual workload.
              </p>
            </div>
          ))}
        </div>
      </section>

      <section className="max-w-7xl mx-auto px-6 py-24">
        <h2 className="text-4xl font-bold text-center mb-16">
          How It Works
        </h2>

        <div className="grid md:grid-cols-4 gap-6">
          {[
            'Connect Support Channels',
            'Train AI On Knowledge Base',
            'AI Handles Requests',
            'Focus On High-Value Work',
          ].map((step, index) => (
            <div
              key={step}
              className="rounded-2xl border border-white/10 bg-white/5 p-6"
            >
              <div className="text-4xl font-bold mb-4">0{index + 1}</div>
              <div>{step}</div>
            </div>
          ))}
        </div>
      </section>

      <section className="max-w-7xl mx-auto px-6 py-24">
        <h2 className="text-4xl font-bold text-center mb-16">
          Proven Results
        </h2>

        <div className="grid md:grid-cols-2 gap-6">
          <div className="rounded-3xl border border-white/10 bg-white/5 p-8">
            <h3 className="text-2xl font-semibold mb-4">
              Ecommerce Brand
            </h3>
            <p className="text-gray-400">
              73% reduction in support workload and 4x faster customer response
              times.
            </p>
          </div>

          <div className="rounded-3xl border border-white/10 bg-white/5 p-8">
            <h3 className="text-2xl font-semibold mb-4">
              SaaS Company
            </h3>
            <p className="text-gray-400">
              62% fewer tickets reaching agents and 35% lower support costs.
            </p>
          </div>
        </div>
      </section>

      <section className="max-w-7xl mx-auto px-6 py-24">
        <h2 className="text-4xl font-bold text-center mb-16">
          Pricing
        </h2>

        <div className="grid md:grid-cols-3 gap-6">
          {['Professional', 'Growth', 'Enterprise'].map((plan) => (
            <div
              key={plan}
              className="rounded-3xl border border-white/10 bg-white/5 p-8"
            >
              <h3 className="text-2xl font-bold">{plan}</h3>
              <p className="text-gray-400 mt-4">
                Custom implementation tailored to your business.
              </p>
            </div>
          ))}
        </div>
      </section>

      <section className="max-w-5xl mx-auto px-6 py-24 text-center">
        <h2 className="text-5xl font-bold">
          Support More Customers Without Hiring More Agents
        </h2>

        <p className="text-gray-400 mt-6 text-lg">
          Join modern companies using AI to automate customer support at scale.
        </p>

        <button className="mt-10 px-8 py-4 rounded-xl bg-white text-black font-semibold">
          Schedule Strategy Call
        </button>
      </section>
    </main>
  )
}
